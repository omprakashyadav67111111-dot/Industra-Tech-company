    
    <?php include 'header.php'; ?>
    
     
    <link rel="stylesheet" href="style.css">
 
 
 <!-- MAIN -->
  <main class="main-content">

    <!-- TOP BAR -->
    <div class="top-bar">
      <h1>Dashboard</h1>
      <div class="profile">
        <span>Admin</span>
        <img src="https://i.pravatar.cc/100" alt="profile">
      </div>
    </div>

    <!-- CARDS -->
    <section class="cards">
      <div class="card">
        <h3>Total Users</h3>
        <p>120</p>
        <i class="fa-solid fa-users"></i>
      </div>
      <div class="card">
        <h3>Services</h3>
        <p>8</p>
        <i class="fa-solid fa-gear"></i>
      </div>
      <div class="card">
        <h3>Enquiries</h3>
        <p>35</p>
        <i class="fa-solid fa-envelope"></i>
      </div>
    </section>

    <!-- TABLE -->
    <section class="table-section">
      <h2>Recent Enquiries</h2>
      <table>
        <tr>
          <th>Name</th>
          <th>Email</th>
          <th>Status</th>
        </tr>
        <tr>
          <td>Rahul</td>
          <td>rahul@gmail.com</td>
          <td><span class="status pending">Pending</span></td>
        </tr>
        <tr>
          <td>Amit</td>
          <td>amit@gmail.com</td>
          <td><span class="status done">Done</span></td>
        </tr>
      </table>
    </section>