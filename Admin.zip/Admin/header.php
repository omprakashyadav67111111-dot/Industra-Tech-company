<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Company Admin Panel</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<!-- Google Font -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">

<link rel="stylesheet" href="style.css">
</head>
 
<body>

<div class="admin-container">

 
  <!-- SIDEBAR -->
<aside class="sidebar">
    <h2>Company Admin</h2>
    <ul>
        <li><a href="dashboard.php"><i class="fa-solid fa-chart-line"></i> Dashboard</a></li>
        <li><a href="users.php"><i class="fa-solid fa-users"></i> Users</a></li>
        <li><a href="services.php"><i class="fa-solid fa-gear"></i> Services</a></li>
        <li><a href="contact_accounts.php"><i class="fa-solid fa-file-lines"></i> contact_accounts</a></li>
        <li><a href="settings.php"><i class="fa-solid fa-sliders"></i> Settings</a></li>
        <li class="logout"><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i> Logout</a></li>
    </ul>
</aside>
