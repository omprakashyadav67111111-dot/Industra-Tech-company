<?php
echo password_hash("love you om", PASSWORD_DEFAULT);
?>
