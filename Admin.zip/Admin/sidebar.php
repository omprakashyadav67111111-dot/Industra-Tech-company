  <!-- SIDEBAR -->
  <aside class="sidebar">
    <h2>Company Admin</h2>
    <ul>
      <li><i class="fa-solid fa-chart-line"></i> Dashboard</li>
      <li><i class="fa-solid fa-users"></i> Users</li>
      <li><i class="fa-solid fa-gear"></i> Services</li>
      <li><i class="fa-solid fa-file-lines"></i> Contact</li>
      <li><i class="fa-solid fa-sliders"></i> Settings</li>
      <li class="logout"><i class="fa-solid fa-right-from-bracket"></i> Logout</li>
    </ul>
  </aside>