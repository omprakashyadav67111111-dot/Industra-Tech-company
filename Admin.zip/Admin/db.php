<?php
// db.php

$host = "localhost";     // ✅ Usually localhost
$user = "root";          // ✅ phpMyAdmin username, default XAMPP me 'root'
$pass = "";              // ✅ Password, XAMPP/WAMP me mostly blank
$db   = "company";       // ✅ Aapka database name, check kar lein ki 'company' exist karta ho

// Create connection
$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error); // ✅ Agar connection fail hua to error dikhaye
}

// Optional: set charset (recommended)
$conn->set_charset("utf8"); // ✅ UTF-8 charset set karna acha hai taaki special characters properly handle ho
?>
