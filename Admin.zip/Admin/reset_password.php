<?php
include "db.php";

$newPassword = "love you om";
$newHash = password_hash($newPassword, PASSWORD_DEFAULT);

$sql = "UPDATE users SET password='$newHash' WHERE username='khushi'";
mysqli_query($conn, $sql);

echo "PASSWORD RESET DONE";
