<?php
session_start();
include "db.php";

$error = "";

if(isset($_POST['login'])){

  $username = trim($_POST['username']);
  $password = $_POST['password'];

  $stmt = $conn->prepare("SELECT * FROM users WHERE username=?");
  $stmt->bind_param("s", $username);
  $stmt->execute();
  $result = $stmt->get_result();

  if($result->num_rows === 1){

    $row = $result->fetch_assoc();

    if(password_verify($password, $row['password'])){
      $_SESSION['username'] = $row['username'];
      header("Location: dashboard.php");
      exit;
    }else{
      $error = "Wrong Password!";
    }

  }else{
    $error = "User not found!";
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Login</title>

<style>
*{
  margin:0;
  padding:0;
  box-sizing:border-box;
  font-family:'Poppins', sans-serif;
}

body{
  min-height:100vh;
  display:flex;
  align-items:center;
  justify-content:center;
  background:linear-gradient(120deg,#0f4c75,#3282b8);
}

.login-box{
  width:380px;
  background:#fff;
  border-radius:16px;
  padding:35px 30px;
  box-shadow:0 20px 40px rgba(0,0,0,0.25);
}

.login-box h2{
  text-align:center;
  color:#0f4c75;
  margin-bottom:20px;
}

.input-group{
  margin-bottom:20px;
}

.input-group label{
  display:block;
  margin-bottom:6px;
  font-size:14px;
}

.input-group input{
  width:100%;
  padding:12px;
  border:1px solid #ccc;
  border-radius:8px;
}

.login-btn{
  width:100%;
  padding:12px;
  background:#0f4c75;
  border:none;
  border-radius:30px;
  color:#fff;
  font-size:15px;
  cursor:pointer;
}

.error-message{
  color:red;
  text-align:center;
  margin-bottom:15px;
}
</style>
</head>

<body>

<div class="login-box">
  <h2>Login</h2>

  <?php if(!empty($error)): ?>
    <div class="error-message"><?php echo $error; ?></div>
  <?php endif; ?>

  <form method="post">
    <div class="input-group">
      <label>Username</label>
      <input type="text" name="username" required>
    </div>

    <div class="input-group">
      <label>Password</label>
      <input type="password" name="password" required>
    </div>

    <button type="submit" name="login" class="login-btn">Login</button>
  </form>
</div>

</body>
</html>
