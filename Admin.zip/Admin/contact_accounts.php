<?php
include 'header.php';
include 'db.php';

// pagination settings
$limit = 8; // ek page par records
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$page = max($page, 1);
$offset = ($page - 1) * $limit;

// total records
$totalQuery = $conn->query("SELECT COUNT(*) AS total FROM contact_accounts");
$totalRow = $totalQuery->fetch_assoc();
$totalRecords = $totalRow['total'];
$totalPages = ceil($totalRecords / $limit);
?>

<style>
.page-wrap{
    max-width:1200px;
    margin:0 auto;
    padding:30px 20px;
    background:linear-gradient(135deg,#eef3f8,#f9fbfd);
    min-height:100vh;
}

/* HEADER */
.page-title{
  text-align:center;
  margin-bottom:25px;
}
.page-title h1{
  color:#0f4c75;
  font-size:28px;
}
.page-title p{
  color:#555;
  font-size:14px;
}

/* TABLE BOX */
.table-box{
  background:#fff;
  border-radius:14px;
  box-shadow:0 10px 30px rgba(0,0,0,0.08);
  overflow-x:auto;
}

/* TABLE */
table{
  width: 1160px;
  border-collapse:collapse;
}

thead{
  background:linear-gradient(135deg,#0f4c75,#3282b8);
  color:#fff;
}

th, td{
  padding:14px 12px;
  font-size:14px;
  border-bottom:1px solid #e6e6e6;
  text-align:left;
}

tbody tr:hover{
  background:#f1f6fb;
}

/* STATUS */
.tag{
  padding:5px 12px;
  border-radius:20px;
  font-size:12px;
  color:#fff;
  background:#16a34a;
}

/* PAGINATION */
.pagination{
  margin-top:25px;
  display:flex;
  justify-content:center;
  gap:8px;
  flex-wrap:wrap;
}

.pagination a{
  padding:8px 14px;
  background:#fff;
  border:1px solid #ddd;
  border-radius:6px;
  text-decoration:none;
  color:#0f4c75;
  font-size:14px;
}

.pagination a.active{
  background:#0f4c75;
  color:#fff;
  border-color:#0f4c75;
}

.pagination a:hover{
  background:#3282b8;
  color:#fff;
}
</style>

<div class="page-wrap">

  <div class="page-title">
    <h1>Contact Account</h1>
    <p>Industrial Company – Contact Record System</p>
  </div>

  <div class="table-box">
    <table>
      <thead>
        <tr>
          <th>S.No</th>
          <th>Name</th>
          <th>Mobile</th>
          <th>Email</th>
          <th>Message</th>
          <th>Status</th>
        </tr>
      </thead>

      <tbody>
        <?php
        $sql = "SELECT * FROM contact_accounts ORDER BY id DESC LIMIT $limit OFFSET $offset";
        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {
            $sn = $offset + 1;
            while ($row = $result->fetch_assoc()) {
        ?>
        <tr>
          <td><?php echo $sn++; ?></td>
          <td><?php echo htmlspecialchars($row['name']); ?></td>
          <td><?php echo htmlspecialchars($row['mobile']); ?></td>
          <td><?php echo htmlspecialchars($row['email']); ?></td>
          <td><?php echo htmlspecialchars($row['message']); ?></td>
          <td>
            <span class="tag"><?php echo htmlspecialchars($row['status']); ?></span>
          </td>
        </tr>
        <?php
            }
        } else {
            echo "<tr><td colspan='6' style='text-align:center;'>No records found</td></tr>";
        }
        ?>
      </tbody>
    </table>
  </div>

  <!-- PAGINATION -->
  <?php if ($totalPages > 1) { ?>
  <div class="pagination">
    <?php if ($page > 1) { ?>
      <a href="?page=<?php echo $page-1; ?>">Previous</a>
    <?php } ?>

    <?php for ($i = 1; $i <= $totalPages; $i++) { ?>
      <a href="?page=<?php echo $i; ?>" class="<?php echo ($i == $page) ? 'active' : ''; ?>">
        <?php echo $i; ?>
      </a>
    <?php } ?>

    <?php if ($page < $totalPages) { ?>
      <a href="?page=<?php echo $page+1; ?>">Next</a>
    <?php } ?>
  </div>
  <?php } ?>

</div>
