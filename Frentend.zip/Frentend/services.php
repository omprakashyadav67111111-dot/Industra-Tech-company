<?php include 'header.php'; ?>
 
<link rel="stylesheet" href="css/style.css">

 
<style>
    /* ===== Services Hero Section ===== */
 .services-hero {
    position: relative;
    width: 100%;
    height: 350px;
    display: flex;
    justify-content: center;
    align-items: center;
    text-align: center;
    overflow: hidden;
    background: url('https://img.freepik.com/free-vector/background-realistic-abstract-technology-particle_23-2148431735.jpg?semt=ais_hybrid&w=740&q=80') center/cover no-repeat;
   }

   .hero-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    /* background: rgba(10,15,36,0.75); */
    z-index: 1;
    }

   .hero-content {
    position: relative;
    z-index: 2;
    max-width: 800px;
    padding: 0 20px;
  }

   .hero-title {
    font-size: 3rem;
    color: #ffb400;
    margin-bottom: 20px;
    opacity: 0;
    transform: translateY(-20px);
    animation: slideFade 1s forwards;
  }

  .hero-subtitle {
    font-size: 1.2rem;
    color: #ccc;
    margin-bottom: 30px;
    opacity: 0;
    transform: translateY(20px);
    animation: slideFade 1s 0.5s forwards;
  }

  .hero-btn {
    display: inline-block;
    padding: 12px 30px;
    background: #ffb400;
    color: #0a0f24;
    font-weight: 600;
    border-radius: 5px;
    transition: all 0.3s ease;
    opacity: 0;
    transform: translateY(20px);
    animation: slideFade 1s 1s forwards;
   }

  .hero-btn:hover {
    background: #ffd666;
   }

    /* ===== Hero Animation ===== */
    @keyframes slideFade {
    to {
        opacity: 1;
        transform: translateY(0);
    }
  }

   /* ===== Responsive ===== */
  @media (max-width: 768px) {
    .hero-title {
        font-size: 2rem;
    }
    .hero-subtitle {
        font-size: 1rem;
    }
  }
</style>
<br>
<br>
  <br>
  

<!-- ===== Services Hero Section Start ===== -->
<section class="services-hero">
    <!-- Overlay -->
    <div class="hero-overlay"></div>

    <!-- Content -->
    <div class="hero-content">
        <h1 class="hero-title">Our Services</h1>
        <p class="hero-subtitle">
            Cutting-edge industrial solutions in automation, engineering, and infrastructure to empower your business.
        </p>
        <a href="#services" class="hero-btn">Explore Services</a>
    </div>
</section>

   <!-- Un-Compromised Quality -->

<section class="quality-section">
  <div class="top-bar">
    <h2>40+ Years of Un-Compromised Quality</h2>
    <a href="#" class="inquiry-btn">Make an Inquiry ➜</a>
  </div>

  <div class="product-section">
    <div class="product-category">
      <h3>Elastics Bands</h3>
      <div class="product-grid">
        <div class="product-card reveal">
          <img src="https://www.theblackcanvas.in/cdn/shop/files/coloured-elastic-bands_7666336f-ad3b-4b27-9f0a-fb0eb3cb9878.jpg?v=1708941484" alt="Elastic Band 1">
        </div>
        <div class="product-card reveal">
          <img src="https://images-cdn.ubuy.co.in/633b1b2d1d7a6b0ed51f7567-elastic-bands-for-sewing-1-inch-wide.jpg" alt="Elastic Band 2">
        </div>
      </div>
    </div>

    <div class="product-category">
      <h3>Superseal zippers for Water Ball</h3>
      <div class="product-grid">
        <div class="product-card reveal">
          <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ6GOLQ6GSN5F8g276tPSIGS_L4qq33THPfrQ&s" alt="Water Ball 1">
        </div>
        <div class="product-card reveal">
          <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSGL10cjQHI2RrGTGBNcwjbvJUu5zePDnnaZA&s" alt="Water Ball 2">
        </div>
      </div>
    </div>
  </div>
</section>         

  <?php include 'footer.php'; ?>

<script src="js/script.js"></script>