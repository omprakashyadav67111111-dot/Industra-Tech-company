<!-- ===== Footer Start ===== -->
<footer class="footer">
  <div class="container">
    <div class="footer-content">

      <!-- Company Info -->
      <div class="footer-col company">
        <h2 class="logo">Industra<span>Tech</span></h2>
        <p>
          We deliver innovative industrial solutions and engineering excellence
          to enhance productivity and sustainability worldwide.
        </p>

        <div class="social-links">
          <a href="#"><i class="fab fa-facebook-f"></i></a>
          <a href="#"><i class="fab fa-twitter"></i></a>
          <a href="#"><i class="fab fa-linkedin-in"></i></a>
          <a href="#"><i class="fab fa-instagram"></i></a>
        </div>
      </div>

      <!-- Quick Links -->
      <div class="footer-col links">
        <h4>Quick Links</h4>
        <ul>
          <li><a href="index.php">Home</a></li>
          <li><a href="about.php">About Us</a></li>
          <li><a href="services.php">Services</a></li>
          <li><a href="contact.php">Contact</a></li>
        </ul>
      </div>

      <!-- Contact Info -->
      <div class="footer-col contact">
        <h4>Contact Info</h4>
        <ul>
          <li><i class="fas fa-map-marker-alt"></i> Industrial Park, Mumbai, India</li>
          <li><i class="fas fa-phone-alt"></i> +91 98765 43210</li>
          <li><i class="fas fa-envelope"></i> info@industratech.com</li>
        </ul>
      </div>

    </div>

    <!-- Footer Bottom -->
    <div class="footer-bottom">
      <p>© <?php echo date("Y"); ?> <span>IndustraTech</span>. All Rights Reserved.</p>
    </div>
  </div>
</footer>
<!-- ===== Footer End ===== -->
