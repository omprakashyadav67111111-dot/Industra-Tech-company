<?php include 'header.php'; ?>
 
<?php
include 'db.php'; // database connection

$success = '';
$error = '';

if (isset($_POST['submit'])) {

    $name    = trim($_POST['name']);
    $email   = trim($_POST['email']);
    $mobile  = trim($_POST['mobile']);
    $message = trim($_POST['message']);

    // Secure Prepared Statement
    $stmt = $conn->prepare(
        "INSERT INTO contact_accounts (name, mobile, email, message)
         VALUES (?, ?, ?, ?)"
    );

    if ($stmt) {
        $stmt->bind_param("ssss", $name, $mobile, $email, $message);

        if ($stmt->execute()) {
            // $success = "Your message has been sent successfully!";
        } else {
            $error = "Form submit nahi hua!";
        }

        $stmt->close();
    } else {
        $error = "Query prepare error!";
    }
}
?>


<link rel="stylesheet" href="css/style.css">

<style>
   /* contact */
  /* ===== Hero Section ===== */
    .contact-hero {
      background: linear-gradient(rgba(10,35,66,0.7), rgba(10,35,66,0.7)), url('https://www.vendorlist.in/wp-content/uploads/2022/09/Manufacturing-Industries-in-Bengaluru.jpg.webp') center/cover no-repeat;
      padding: 143px 20px;
      text-align: center;
      color: #fff;
    }

    .contact-hero h1 {
      font-size: 2.5rem;
      margin-bottom: 10px;
      animation: fadeInDown 1s ease forwards;
    }

    .contact-hero p {
      font-size: 1.1rem;
      animation: fadeIn 1.5s ease forwards;
    }

    /* ===== Contact Section ===== */
    .contact-section {
      max-width: 1100px;
      margin: 40px auto;
      display: flex;
      flex-wrap: wrap;
      gap: 30px;
      padding: 0 20px;
    }

    /* Form */
    .contact-form {
      flex: 1;
      min-width: 300px;
      background: #fff;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 0 15px rgba(0,0,0,0.1);
      animation: fadeInLeft 1s ease forwards;
    }

    .contact-form h2 {
      margin-bottom: 20px;
      color: #0a2342;
    }

    .contact-form input, .contact-form textarea {
      width: 100%;
      padding: 12px 15px;
      margin-bottom: 15px;
      border: 1px solid #ccc;
      border-radius: 6px;
      font-size: 0.95rem;
      transition: all 0.3s;
    }

    .contact-form input:focus, .contact-form textarea:focus {
      border-color: #ffb400;
      box-shadow: 0 0 8px #ffb400;
      outline: none;
    }

    .contact-form button {
      padding: 12px 25px;
      background: #ffb400;
      border: none;
      border-radius: 6px;
      color: #fff;
      font-weight: bold;
      cursor: pointer;
      transition: all 0.3s;
    }

    .contact-form button:hover {
      background: #fff;
      color: #ffb400;
      transform: scale(1.05);
      box-shadow: 0 0 15px #ffb400;
    }

    /* Info Box */
    .contact-info {
      flex: 1;
      min-width: 250px;
      background: #0a2342;
      color: #fff;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 0 15px rgba(0,0,0,0.1);
      animation: fadeInRight 1s ease forwards;
    }

    .contact-info h3 {
      margin-bottom: 15px;
      color: #ffb400;
    }

    .contact-info p {
      margin-bottom: 12px;
      font-size: 0.95rem;
    }

    /* Animations */
    @keyframes fadeInDown {
      0% { opacity: 0; transform: translateY(-20px); }
      100% { opacity: 1; transform: translateY(0); }
    }

    @keyframes fadeIn {
      0% { opacity: 0; }
      100% { opacity: 1; }
    }

    @keyframes fadeInLeft {
      0% { opacity: 0; transform: translateX(-30px); }
      100% { opacity: 1; transform: translateX(0); }
    }

    @keyframes fadeInRight {
      0% { opacity: 0; transform: translateX(30px); }
      100% { opacity: 1; transform: translateX(0); }
    }

    /* Responsive */
    @media(max-width: 768px) {
      .contact-section {
        flex-direction: column;
      }
    }

 
</style>


  <!-- Hero Section -->
  <section class="contact-hero">
    <h1>Contact Us</h1>
    <p>We’re here to help your industrial business grow. Reach out to us today!</p>
  </section>

  <!-- Contact Section -->
  <section class="contact-section">
    
<div class="contact-form">

  <?php if (!empty($success)) { ?>
    <div class="success-msg"><?php echo $success; ?></div>
  <?php } ?>

  <?php if (!empty($error)) { ?>
    <div class="error-msg"><?php echo $error; ?></div>
  <?php } ?>

  <form method="POST" action="">
    <div class="form-group">
      <input type="text" name="name" placeholder="Your Name" required>
    </div>

    <div class="form-group">
      <input type="email" name="email" placeholder="Your Email" required>
    </div>

    <div class="form-group">
      <input type="text" name="mobile" placeholder="Your Mobile Number" required>
    </div>

    <div class="form-group">
      <textarea name="message" placeholder="Your Message" rows="5" required></textarea>
    </div>

    <!-- ✅ IMPORTANT -->
    <button type="submit" name="submit">Send Message</button>
  </form>

</div>




    <!-- Contact Info -->
    <div class="contact-info">
      <h3>Our Office</h3>
      <p><strong>Address:</strong> 123 Industrial Road, Partapur, Meerut</p>
      <p><strong>Email:</strong> info@industratech.com</p>
      <p><strong>Phone:</strong> +91 98765 43210</p>
      <p><strong>Working Hours:</strong> Mon - Fri, 9:00 AM - 6:00 PM</p>
    </div>

  </section>
  <?php include 'footer.php'; ?>

<script src="js/script.js"></script>