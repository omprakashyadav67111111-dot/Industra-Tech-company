<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "company";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Database Connection Failed");
}
?>
