<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Industrial Company | Hero Section</title>
  <link rel="stylesheet" href="css/style.css">
</head>

<body>

<!-- ===== Header Start ===== -->
<header id="header">
  <div class="container">
    <h1 class="logo">Industra<span>Tech</span></h1>

    <!-- Navigation -->
    <nav class="nav" id="nav-menu">
      <ul>
        <li><a href="index.php" class="active">Home</a></li>
        <li><a href="about.php">About</a></li>
        <li><a href="services.php">Services</a></li>
        <li><a href="contact.php">Contact</a></li>
      </ul>
    </nav>

    <!-- Mobile Menu Icon -->
    <div class="menu-toggle" id="menu-toggle">
      <span></span>
      <span></span>
      <span></span>
    </div>
  </div>
</header>
<!-- ===== Header End ===== -->
<script src="js/main.js"></script>
