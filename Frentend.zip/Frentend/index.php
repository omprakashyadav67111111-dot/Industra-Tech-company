<?php include 'header.php'; ?>
 
<link rel="stylesheet" href="css/style.css">

  <!-- Hero Section -->
  <section class="hero" id="home">
    <div class="overlay"></div>
    <div class="hero-content">
      <h1>Engineering the Future of Industry</h1>
      <p>Innovative, Reliable & Sustainable Industrial Solutions</p>
      <a href="#services" class="btn">Explore Our Work</a>
    </div>
  </section>

  <!-- ABOUT SECTION -->
  <section class="about reveal" id="about">
    <img src="./Assets/About.jpg" alt="Factory">
    <div class="text">
      <h2>About Our Company</h2>
      <p>
        At IndustraTech, we are driven by innovation and engineering excellence. 
        With decades of experience in manufacturing and industrial automation, 
        we specialize in creating sustainable and efficient solutions tailored to 
        meet the unique needs of our clients.
      </p>
    </div>
  </section>

 
  <!-- WHAT WE DO SECTION -->
  <section class="section-container" id="section">

    <!-- Top Section -->
    <div class="top-row">
      <div class="circle-logo"></div>
      <div>
        <div class="kicker">WHAT WE DO</div>
        <h1 class="main-heading">
          Subros is a market leader in designing and manufacturing of a wide range of thermal solutions in India
        </h1>
        <a href="#" class="read-more">Read More</a>
      </div>
    </div>

    <div class="separator"></div>

    <!-- Main Grid -->
    <div class="grid">
      <!-- Left Card -->
      <div class="left-card" id="leftCard">
        <h3>Thermal system<br>solutions for</h3>
      </div>

      <!-- Auto Scrolling Cards -->
      <div class="scroll-container">
        <div class="items">
          <!-- Item 1 -->
       <article class="item">
               <div class="thumb">
                <img src="./Assets/Passenger Vehicle.jpg" alt="Passenger Vehicle" class="thumb-img">
                </div>
                 <a href="#">Passenger Vehicle</a>
                </article>


          <!-- Item 2 -->
       <article class="item">
               <div class="thumb">
                <img src="./Assets/Passenger Vehicle 2.webp" alt="Passenger Vehicle" class="thumb-img">
                </div>
                 <a href="#">Passenger Vehicle</a>
                </article>

          <!-- Item 3 -->
         <article class="item">
               <div class="thumb">
                <img src="./Assets/Manufacturing-Industries-in-Bengaluru.jpg 4.webp" alt="Passenger Vehicle" class="thumb-img">
                </div>
                 <a href="#">Passenger Vehicle</a>
                </article>

          <!-- Clone for seamless scroll -->
       <article class="item">
               <div class="thumb">
                <img src="./Assets/Top-10-Industrial-Automation-Companies-in-Peenya2.webp" alt="Passenger Vehicle" class="thumb-img">
                </div>
                 <a href="#">Passenger Vehicle</a>
                </article>
        </div>
      </div>
    </div>
  </section>



<!-- ===== Company Key Features Section (with Hover & Animation) ===== -->
<section class="features" style="display:flex; flex-wrap:wrap; gap:20px; padding:60px 5%; text-align:center;">
 
 

  <div class="feature" style="background-color:#0077b6;">
    <img src="https://img.icons8.com/ios-filled/60/ffffff/factory.png" alt="Modern Infrastructure" />
    <h3 style="margin-top:15px; font-size:22px; font-weight:600;">Modern Infrastructure</h3>
    <p style="margin-top:10px; font-size:15px; line-height:1.6;">
      Equipped with state-of-the-art machinery and advanced technology for efficient production.
    </p>
  </div>

  <div class="feature" style="background-color:#00b4d8;">
    <img src="https://img.icons8.com/ios-filled/60/ffffff/maintenance.png" alt="Quality Assurance" />
    <h3 style="margin-top:15px; font-size:22px; font-weight:600;">Quality Assurance</h3>
    <p style="margin-top:10px; font-size:15px; line-height:1.6;">
      We maintain global quality standards with regular inspection and precision testing.
    </p>
  </div>

  <div class="feature" style="background-color:#007f5f;">
    <img src="https://img.icons8.com/ios-filled/60/ffffff/worker-male.png" alt="Expert Workforce" />
    <h3 style="margin-top:15px; font-size:22px; font-weight:600;">Expert Workforce</h3>
    <p style="margin-top:10px; font-size:15px; line-height:1.6;">
      Our experienced engineers and technicians ensure accuracy and innovation in every project.
    </p>
  </div>

  <div class="feature" style="background-color:#ef233c;">
    <img src="https://img.icons8.com/ios-filled/60/ffffff/truck.png" alt="Timely Delivery" />
    <h3 style="margin-top:15px; font-size:22px; font-weight:600;">Timely Delivery</h3>
    <p style="margin-top:10px; font-size:15px; line-height:1.6;">
      We guarantee on-time delivery with a strong supply chain and reliable logistics support.
    </p>
  </div>

</section>
 
 



  <!-- ===== Top Banner ===== -->
  <div class="image-box">
    <img src="./Assets/Manufacturing-Industries-in-Bengaluru.jpg 4.webp" alt="Industrial Image">
    <div class="image-overlay">
      <h3>Portfolio</h3>
      <p>What We've Done</p>
    </div>
  </div>

  <!-- ===== Portfolio Section ===== -->
  <section id="portfolio">
    <div class="container text-center">
      <div class="section-title reveal">
        <h2>Our Projects</h2>
        <p>Explore our successfully delivered industrial projects</p>
      </div>

      <div class="portfolio-grid">
        <!-- Portfolio Item 1 -->
        <div class="portfolio-item">
          <img src="https://images.unsplash.com/photo-1503387762-592deb58ef4e" alt="Industrial Plant">
          <div class="portfolio-overlay">
            <h4>Oil Refinery Project</h4>
            <p>Complete automation and pipeline design solution.</p>
            <a href="#" class="btn-view">View Details</a>
          </div>
        </div>

        <!-- Portfolio Item 2 -->
        <div class="portfolio-item">
          <img src="https://www.shutterstock.com/image-illustration/3d-render-modern-manufacturing-plant-260nw-2445629971.jpg" alt="Factory Setup">
          <div class="portfolio-overlay">
            <h4>Manufacturing Facility</h4>
            <p>Designed and executed a modern production line setup.</p>
            <a href="#" class="btn-view">View Details</a>
          </div>
        </div>

        <!-- Portfolio Item 3 -->
        <div class="portfolio-item">
          <img src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c" alt="Construction Site">
          <div class="portfolio-overlay">
            <h4>Construction Project</h4>
            <p>Full structural development and material handling systems.</p>
            <a href="#" class="btn-view">View Details</a>
          </div>
        </div>

        <!-- Portfolio Item 4 -->
        <div class="portfolio-item">
          <img src="https://images.unsplash.com/photo-1556761175-5973dc0f32e7" alt="Engineering Design">
          <div class="portfolio-overlay">
            <h4>Engineering Design</h4>
            <p>3D modeling and technical design for heavy machinery units.</p>
            <a href="#" class="btn-view">View Details</a>
          </div>
        </div>
      </div>
    </div>
  </section>


<!-- overloade section -->

  <section class="stats-section">
  <div class="overlay"></div>
  <div class="stats-container">
    <div class="stat-box">
      <h2 class="counter" data-target="40">0</h2><span>+</span>
      <p>Total Experience</p>
    </div>
    <div class="stat-box">
      <h2 class="counter" data-target="21">0</h2><span>+</span>
      <p>Countries Served</p>
    </div>
    <div class="stat-box">
      <h2 class="counter" data-target="5500">0</h2><span>+</span>
      <p>Customers Served</p>
    </div>
    <div class="stat-box">
      <h2 class="counter" data-target="550">0</h2><span>M+</span>
      <p>Meters Zippers Produced</p>
    </div>
  </div>
</section>





<!-- Un-Compromised Quality -->

<section class="quality-section">
  <div class="top-bar">
    <h2>40+ Years of Un-Compromised Quality</h2>
    <a href="#" class="inquiry-btn">Make an Inquiry ➜</a>
  </div>

  <div class="product-section">
    <div class="product-category">
      <h3>Elastics Bands</h3>
      <div class="product-grid">
        <div class="product-card reveal">
          <img src="https://www.theblackcanvas.in/cdn/shop/files/coloured-elastic-bands_7666336f-ad3b-4b27-9f0a-fb0eb3cb9878.jpg?v=1708941484" alt="Elastic Band 1">
        </div>
        <div class="product-card reveal">
          <img src="https://images-cdn.ubuy.co.in/633b1b2d1d7a6b0ed51f7567-elastic-bands-for-sewing-1-inch-wide.jpg" alt="Elastic Band 2">
        </div>
      </div>
    </div>

    <div class="product-category">
      <h3>Superseal zippers for Water Ball</h3>
      <div class="product-grid">
        <div class="product-card reveal">
          <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ6GOLQ6GSN5F8g276tPSIGS_L4qq33THPfrQ&s" alt="Water Ball 1">
        </div>
        <div class="product-card reveal">
          <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSGL10cjQHI2RrGTGBNcwjbvJUu5zePDnnaZA&s" alt="Water Ball 2">
        </div>
      </div>
    </div>
  </div>
</section>

<!-- membership-section -->
  <section class="memberships-section">
    <h2>Industry Memberships</h2>

    <div class="membership-slider">
      <div class="slider-track">
        <div class="slide"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e3/ISO_Logo_%28Red_square%29.svg/1200px-ISO_Logo_%28Red_square%29.svg.png" alt="ISO"></div>
        <div class="slide"><img src="https://t4.ftcdn.net/jpg/01/22/73/39/360_F_122733975_E33WcdFX2GX86vW5Gqki5SuqN6bIUr6Y.jpg" alt="CE"></div>
        <div class="slide"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT8ciCtQqaWlSPKNOjGPXONeiO0T3D-a7pAYQ&s" alt="Bureau Veritas"></div>
        <div class="slide"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTTBlV0_PHzI4MjNF4nBJPEDZxNJVQnKSO42g&s" alt="ISO 14001"></div>
        <div class="slide"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQXFWrCX90YosQpsoGg5KzXgzwEbH1uGSyqbA&s" alt="DNV"></div>
        <div class="slide"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQG1Xb-kQ4C3TyTPHar_1asFt0xA9Vcom9cEw&s" alt="UL"></div>
        <!-- Repeat for smooth loop -->
        <div class="slide"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e3/ISO_Logo_%28Red_square%29.svg/1200px-ISO_Logo_%28Red_square%29.svg.png" alt="ISO"></div>
        <div class="slide"><img src="https://t4.ftcdn.net/jpg/01/22/73/39/360_F_122733975_E33WcdFX2GX86vW5Gqki5SuqN6bIUr6Y.jpg" alt="CE"></div>
        <div class="slide"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT8ciCtQqaWlSPKNOjGPXONeiO0T3D-a7pAYQ&s" alt="Bureau Veritas"></div>
      </div>
    </div>
  </section>
  <?php include 'footer.php'; ?>

<script src="js/script.js"></script>