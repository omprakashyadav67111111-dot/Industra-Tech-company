 
const hero = document.querySelector('.hero');
const images = [
  'https://media.gettyimages.com/id/582256640/photo/oil-refinery-chemical-petrochemical-plant.jpg?s=612x612&w=gi&k=20&c=arDXd67gfBOrWPFBYlHOd04MAIxqr01XJkdCxwBn1dM=',
  'https://marcopolis.net/wp-content/uploads/saudi-arabia-report/2015/companies/top-industrial-companies-in-saudi-arabia.jpg',
  'https://media.gettyimages.com/id/1220887633/photo/chemical-plant-in-tai-po-hong-kong.jpg?s=612x612&w=gi&k=20&c=kY5kXdlLpFNa7qmHgOTED9HlCdCfJtYCqsP1Lio71io='
];    


let current = 0;
function changeSlide() {
  hero.classList.add('slide-change');
  setTimeout(() => {
    current = (current + 1) % images.length;
    hero.style.backgroundImage = `url(${images[current]})`;
  }, 500);
  setTimeout(() => { hero.classList.remove('slide-change'); }, 1200);
}
setInterval(changeSlide, 5000);

// Scroll Reveal Animation
window.addEventListener("scroll", () => {
  document.querySelectorAll(".reveal").forEach((el) => {
    let windowHeight = window.innerHeight;
    let elementTop = el.getBoundingClientRect().top;
    if (elementTop < windowHeight - 100) el.classList.add("active");
  });
});

// Header and Mobile Menu Script
 
const header = document.getElementById('header');
const menuToggle = document.getElementById('menu-toggle');
const navMenu = document.getElementById('nav-menu');

// Sticky Header on Scroll
window.addEventListener('scroll', () => {
  header.classList.toggle('scrolled', window.scrollY > 50);
});

// Mobile Menu Toggle
menuToggle.addEventListener('click', () => {
  menuToggle.classList.toggle('active');
  navMenu.classList.toggle('open');
});
 


 
  // Scroll animation for cards
  window.addEventListener("scroll", () => {
    const cards = document.querySelectorAll(".card");
    const windowHeight = window.innerHeight;
    cards.forEach(card => {
      const top = card.getBoundingClientRect().top;
      if(top < windowHeight - 100){
        card.style.opacity = "1";
        card.style.transform = "translateY(0)";
      }
    });
  });

  // Hover effect
  const allCards = document.querySelectorAll(".card");
  allCards.forEach(card => {
    card.addEventListener("mouseenter", () => {
      card.style.transform = "translateY(-10px)";
      card.style.boxShadow = "0 15px 30px rgba(0,0,0,0.2)";
    });
    card.addEventListener("mouseleave", () => {
      card.style.transform = "translateY(0)";
      card.style.boxShadow = "0 5px 20px rgba(0,0,0,0.1)";
    });
  });

// Reveal on scroll animations 
const section = document.getElementById('section');
const leftCard = document.getElementById('leftCard');
const observer = new IntersectionObserver(entries=>{
  entries.forEach(e=>{
    if(e.isIntersecting){
      section.classList.add('visible');
      leftCard.classList.add('visible');
    }
  });
},{threshold:0.3});
observer.observe(section);


  function revealOnScroll() {
      const reveals = document.querySelectorAll(".portfolio-item, .reveal");
      for (let i = 0; i < reveals.length; i++) {
        const windowHeight = window.innerHeight;
        const elementTop = reveals[i].getBoundingClientRect().top;
        const revealPoint = 120;
        if (elementTop < windowHeight - revealPoint) {
          reveals[i].classList.add("active");
          reveals[i].style.opacity = "1";
          reveals[i].style.transform = "translateX(0)";
        }
      }
    }

    window.addEventListener("scroll", revealOnScroll);
    revealOnScroll();



    //overloade section 



    document.addEventListener("DOMContentLoaded", () => {
  const counters = document.querySelectorAll('.counter');
  const speed = 200; // lower is faster

  const animateCounters = () => {
    counters.forEach(counter => {
      const updateCount = () => {
        const target = +counter.getAttribute('data-target');
        const count = +counter.innerText;
        const increment = target / speed;

        if (count < target) {
          counter.innerText = Math.ceil(count + increment);
          setTimeout(updateCount, 20);
        } else {
          counter.innerText = target;
        }
      };
      updateCount();
    });
  };

  // Animate only when visible
  const observer = new IntersectionObserver(entries => {
    if (entries[0].isIntersecting) {
      animateCounters();
      observer.disconnect();
    }
  }, { threshold: 0.3 });

  observer.observe(document.querySelector('.stats-section'));
});




//Un-Compromised Quality



window.addEventListener('scroll', reveal);

function reveal() {
  const reveals = document.querySelectorAll('.reveal');
  for (let i = 0; i < reveals.length; i++) {
    const windowHeight = window.innerHeight;
    const revealTop = reveals[i].getBoundingClientRect().top;
    const revealPoint = 100;

    if (revealTop < windowHeight - revealPoint) {
      reveals[i].classList.add('active');
    } else {
      reveals[i].classList.remove('active');
    }
  }
}

window.addEventListener('scroll', function() {
  const header = document.getElementById('header');
  if (window.scrollY > 50) {
    header.classList.add('scrolled');
  } else {
    header.classList.remove('scrolled');
  }
});



 