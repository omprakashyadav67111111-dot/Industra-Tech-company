<?php include 'header.php'; ?>
 
<link rel="stylesheet" href="css/style.css">


 <!-- ABOUT SECTION -->
  <section class="about reveal" id="about">
    <img src="./Assets/About.jpg" alt="Factory">    
       <div class="text">
      <h2>About Our Company</h2>
      <p>
        At IndustraTech, we are driven by innovation and engineering excellence. 
        With decades of experience in manufacturing and industrial automation, 
        we specialize in creating sustainable and efficient solutions tailored to 
        meet the unique needs of our clients.
      </p>
    </div>
  </section>

   <!-- WHAT WE DO SECTION -->
  <section class="section-container" id="section">

    <!-- Top Section -->
    <div class="top-row">
      <div class="circle-logo"></div>
      <div>
        <div class="kicker">WHAT WE DO</div>
        <h1 class="main-heading">
          Subros is a market leader in designing and manufacturing of a wide range of thermal solutions in India
        </h1>
        <a href="#" class="read-more">Read More</a>
      </div>
    </div>

    <div class="separator"></div>

    <!-- Main Grid -->
    <div class="grid">
      <!-- Left Card -->
      <div class="left-card" id="leftCard">
        <h3>Thermal system<br>solutions for</h3>
      </div>

      <!-- Auto Scrolling Cards -->
      <div class="scroll-container">
        <div class="items">
          <!-- Item 1 -->
       <article class="item">
               <div class="thumb">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSeUSDIqw9HhGWFDG7yyfq0zmSgxxRj3GisVQ&s" alt="Passenger Vehicle" class="thumb-img">
                </div>
                 <a href="#">Passenger Vehicle</a>
                </article>


          <!-- Item 2 -->
       <article class="item">
               <div class="thumb">
                <img src="https://content.jdmagicbox.com/comp/def_content_category/industrial-robotic-automation-dealers/360-f-1254152382-h7tffopwqqwzpixbygkuvd5rwt5xt9vs-industrial-robotic-automation-dealers-1-o3gxl-250.jpg" alt="Passenger Vehicle" class="thumb-img">
                </div>
                 <a href="#">Passenger Vehicle</a>
                </article>

          <!-- Item 3 -->
         <article class="item">
               <div class="thumb">
                <img src="https://www.vendorlist.in/wp-content/uploads/2022/09/Manufacturing-Industries-in-Bengaluru.jpg.webp" alt="Passenger Vehicle" class="thumb-img">
                </div>
                 <a href="#">Passenger Vehicle</a>
                </article>

          <!-- Clone for seamless scroll -->
       <article class="item">
               <div class="thumb">
                <img src="https://cdn-ilajkdd.nitrocdn.com/CFCJXhfiSzTqAgTvTONhpNQKyruYmLIw/assets/images/optimized/rev-5087c10/www.unseenera.com/wp-content/uploads/2025/03/Top-10-Industrial-Automation-Companies-in-Peenya2.webp" alt="Passenger Vehicle" class="thumb-img">
                </div>
                 <a href="#">Passenger Vehicle</a>
                </article>
        </div>
      </div>
    </div>
  </section>



<!-- ===== Company Key Features Section (with Hover & Animation) ===== -->
<section class="features" style="display:flex; flex-wrap:wrap; gap:20px; padding:60px 5%; text-align:center;">
 
 

  <div class="feature" style="background-color:#0077b6;">
    <img src="https://img.icons8.com/ios-filled/60/ffffff/factory.png" alt="Modern Infrastructure" />
    <h3 style="margin-top:15px; font-size:22px; font-weight:600;">Modern Infrastructure</h3>
    <p style="margin-top:10px; font-size:15px; line-height:1.6;">
      Equipped with state-of-the-art machinery and advanced technology for efficient production.
    </p>
  </div>

  <div class="feature" style="background-color:#00b4d8;">
    <img src="https://img.icons8.com/ios-filled/60/ffffff/maintenance.png" alt="Quality Assurance" />
    <h3 style="margin-top:15px; font-size:22px; font-weight:600;">Quality Assurance</h3>
    <p style="margin-top:10px; font-size:15px; line-height:1.6;">
      We maintain global quality standards with regular inspection and precision testing.
    </p>
  </div>

  <div class="feature" style="background-color:#007f5f;">
    <img src="https://img.icons8.com/ios-filled/60/ffffff/worker-male.png" alt="Expert Workforce" />
    <h3 style="margin-top:15px; font-size:22px; font-weight:600;">Expert Workforce</h3>
    <p style="margin-top:10px; font-size:15px; line-height:1.6;">
      Our experienced engineers and technicians ensure accuracy and innovation in every project.
    </p>
  </div>

  <div class="feature" style="background-color:#ef233c;">
    <img src="https://img.icons8.com/ios-filled/60/ffffff/truck.png" alt="Timely Delivery" />
    <h3 style="margin-top:15px; font-size:22px; font-weight:600;">Timely Delivery</h3>
    <p style="margin-top:10px; font-size:15px; line-height:1.6;">
      We guarantee on-time delivery with a strong supply chain and reliable logistics support.
    </p>
  </div>

</section>





 <?php include 'footer.php'; ?>

<script src="js/script.js"></script>